<template>
  <div class="flex justify-center flex-wrap" >
    <div class="flex-none m-8" v-for="(movie, index) in movies" :key="index">
      <div className="card w-96 bg-base-100 shadow-xl image-full">
        <figure><img :src="`https://image.tmdb.org/t/p/w500${movie.poster_path}`" alt="Shoes" /></figure>
        <div className="card-body">
          <h2 className="card-title">{{movie.original_title}}</h2>
          <p>{{movie.overview}}</p>
          <!-- <h1>{{movie.id}}</h1> -->
          <div className="card-actions justify-end">
            <label className="btn btn-primary" for="my-modal"  @click="onClickVidio(movie.id, movie.original_title)">Pop Up</label>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Put this part before </body> tag -->
<input type="checkbox" id="my-modal" class="modal-toggle" />
<div class="modal">
  <div class="modal-box relative max-w-3xl min-h-52">
        <label for="my-modal" class="btn btn-sm btn-circle absolute right-5 top-2 "  @click="pauseVidio">X</label>
          <iframe width="100%" id="vidioItem" ref="root" height="300px" className="mt-5" v-if="moviesVidios.length || 0"
        :src="`https://www.youtube.com/embed/${moviesVidios[0].key}?autoplay=1`" allow="autoplay">
      </iframe>    
      <div class="text-center mt-5 text-white">Data : {{getTitle}}</div>
  </div>
</div>
</template>

<script setup>
import { ref, onMounted, computed, onUnmounted } from "vue";
import { useMovieStore } from "../stores/store.js"

const store = useMovieStore();
var getTitle = '';

onMounted(async () => {
    await store.fetchMovies();
    console.log("reload", store.moviesVidio.length);
});

const  onClickVidio= async (id, name) => {
  store.flim(id);
  console.log(name);
  getTitle = name;
  await store.fetchVidioMovies(); 
    movies.value = store.movies;

  var iframe_vid = document.getElementById('vidioItem');
  var iframe_src = iframe_vid.getAttribute('src');
  var src_stop = iframe_src.replace("?autoplay=0", "?autoplay=1");
  iframe_vid.setAttribute("src", src_stop);
}

const movies = computed(() => {
    return store.movies;
});

const moviesVidios = computed(() => {
  console.log("onclick", store.moviesVidio);

    return store.moviesVidio;
});

function pauseVidio() {
  console.log("Yeah")
  var iframe_vid = document.getElementById('vidioItem');
  var iframe_src = iframe_vid.getAttribute('src');
  var src_stop = iframe_src.replace("?autoplay=1", "?autoplay=0");
  iframe_vid.setAttribute("src", src_stop);

    //return root
}

// const  onClickVidio= async (id) => {
// await store.fetchVidioMovies();
// }


</script>
