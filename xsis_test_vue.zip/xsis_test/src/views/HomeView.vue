<script setup>
import Slider from '../components/Slider.vue'
import Latest from '../components/Latest.vue'
</script>

<template>
  <!-- <Slider /> -->
  <Latest />
</template>
